﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Session_7
{
    class Assi2
    {
        static void Main()
        {
            foreach (string city in Enum.GetNames(typeof(CityEnum)))
            {
                Console.WriteLine(city);
            }

            foreach (int code in Enum.GetValues(typeof(CityEnum)))
            {
                Console.WriteLine(code);
            }
            Console.ReadLine();
        }
    }
}
