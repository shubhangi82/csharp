﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Session_7
{
    class Assi1
    { }
        struct Student
        {
            int RollNo;
            string Name;
            char Gender;
            long MobileNo;

            public Student(int RollNo, string Name, char Gender, long MobileNo)
            {
                this.RollNo = RollNo;
                this.Name = Name;
                this.Gender = Gender;
                this.MobileNo = MobileNo;
            }

        /// <summary>
        /// Display Method to Display Student
        /// </summary>
        /// <returns></returns>
        public string display()
            {
                return string.Format("Roll Number = {0}\n Name = {1}\n Gender(M/F) = {2}\n Mobile No = {3}\n", RollNo, Name, Gender, MobileNo);
            }
        }
    
}
