﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/// <summary>
/// QUE: display student values by creating constructor and print using function
/// </summary>
namespace Session_7
{
    class SutdentAssi1
    {
        static void Main()
        {
            Student std = new Student(100, "shubhangi", 'F', 7758996644);
            Console.WriteLine(std.display());
            Console.ReadLine();
        }
    }
}
