﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/// <summary>
/// QUE : Print all cities STD code in Enum
/// </summary>
namespace Session_7
{
    
        public enum CityEnum
        {
            Pune = 10, Mumbai = 20, Delhi=30
        };
    
}

