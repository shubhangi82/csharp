﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/// <summary>
/// QUE: Calculate Area of circle using Constent
/// </summary>
namespace Session_2
{
    class Assi1
    {
        static void Main()
        {
            const double PI = 3.14;
            Console.WriteLine("enter the redious");
            int r = Convert.ToInt32(Console.ReadLine());
            double aoc = r * r * PI;
            Console.WriteLine(aoc);
            Console.ReadLine();
        }
    }
}
