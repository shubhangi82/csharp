﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/// <summary>
/// QUE: Convert ASCII inti value and vice versa 
/// </summary>
namespace Session_2
{
    class Assi2
    {
        static void Main()
        {
            char c = 'A';
            int ascii = (int)c;
            Console.WriteLine("The ASCII value of " + ascii);
            char n = (char)ascii;
            Console.WriteLine(n);
            Console.ReadLine();

        }
    }
}
