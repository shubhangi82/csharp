﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/// <summary>
///QUE: Develop a program to decide whether person is major or minor using if-else statement.
/// </summary>
namespace Session_3
{
    class Assi1
    {
        static void Main()
        {
            Console.WriteLine("enter your age");

            int i = Convert.ToInt32(Console.ReadLine());
            if (i < 18)
            {
                Console.WriteLine("minor");
            }
            else
            {
                Console.WriteLine("major");
            }
            Console.ReadLine();
        }
    }
}
