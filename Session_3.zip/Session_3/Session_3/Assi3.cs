﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/// <summary>
/// QUE: Develop a program to display name of day from taking input 1-7 using switch case.
/// </summary>
namespace Session_3
{
    class Assi3
    {
        static void Main()
        {
            Console.WriteLine("enter no betn 1to7");
            int num = Convert.ToInt32(Console.ReadLine());
            switch (num)
            {
                case 1:
                    Console.WriteLine("mon");
                    break;
                case 2:
                    Console.WriteLine("tue");
                    break;
                case 3:
                    Console.WriteLine("wed");
                    break;
                case 4:
                    Console.WriteLine("thu");
                    break;
                case 5:
                    Console.WriteLine("fri");
                    break;
                case 6:
                    Console.WriteLine("sat");
                    break;
                case 7:
                    Console.WriteLine("sun");
                    break;
                default:
                    Console.WriteLine("invalid");
                    break;
            }
            Console.ReadLine();
        }
    }
}
