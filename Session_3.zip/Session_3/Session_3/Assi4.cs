﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/// <summary>
/// QUE: Develop a program to decide whether person is major or minor person using Ternary operator.
/// </summary>
namespace Session_3
{
    class Assi4
    {
        static void Main(string[] args)
        {
            Console.Write("enter ur age:");
            int age = Convert.ToInt32(Console.ReadLine());
            string result = age >= 18 ? "major" : "minor";
            Console.WriteLine(result);
            Console.ReadLine();
        }
    }
}
