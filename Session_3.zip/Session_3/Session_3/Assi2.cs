﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/// <summary>
/// QUE: Develop a program to decide grade according to percentage using If-else if-else.
/// </summary>
namespace Session_3
{
    class Assi2
    {
        static void Main()
        {
            Console.WriteLine("enter your percent");
            int per = Convert.ToInt32(Console.ReadLine());
            if (per >= 70)
            {
                Console.WriteLine("dist");
            }
            else if (per >= 60 && per <= 70)
            {
                Console.WriteLine("1st class");
            }
            else if (per >= 50 && per <= 60)
            {
                Console.WriteLine("2nd class");
            }
            else
            {
                Console.WriteLine("fail");
            }
            Console.ReadLine();
        }
    }
}
