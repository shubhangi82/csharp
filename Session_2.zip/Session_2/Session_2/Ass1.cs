﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Session_2
{
    class Ass1
    {
        tatic void Main()
        {
            const double PI = 3.14;
            Console.WriteLine("enter the redious");
            int r = Convert.ToInt32(Console.ReadLine());
            double aoc = r * r * PI;
            Console.WriteLine(aoc);
            Console.ReadLine();
        }
    }
}
