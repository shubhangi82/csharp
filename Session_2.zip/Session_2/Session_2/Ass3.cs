﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/// <summary>
/// QUE: Program to convert Doller into Rupeesss
/// </summary>
namespace Session_2
{
    class Ass3
    {
        static void Main()
        {

            Console.WriteLine("enter doller");
            double doller = Convert.ToInt32(Console.ReadLine());
            double rs;
            rs = doller * 71.76;
            Console.WriteLine("{0} doller={1} rupees=", doller, rs);
            Console.WriteLine("{0} rupees={1} doller=", rs, (rs / doller));
            Console.ReadLine();
        }
    }
}
