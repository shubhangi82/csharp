﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/// <summary>
/// QUE: Sum of Elements of single dimensional array
/// </summary>
namespace Session_5
{
    class Assi1
    {
        static void Main()
        {
            Console.WriteLine("Enter a size Array");
            int size = Convert.ToInt32(Console.ReadLine());
            int[] a = new int[size];
            int sum = 0;
            Console.WriteLine("Enter elements of Array");
            for (int i = 0; i < size; i++)
            {
                a[i] = Convert.ToInt32(Console.ReadLine());
            }

            for (int i = 0; i < size; i++)
            {
                sum = sum + a[i];
            }
            Console.WriteLine("sum={0}", sum);
            Console.ReadLine();
        }
    }
}
