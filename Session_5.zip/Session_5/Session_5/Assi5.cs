﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/// <summary>
/// QUE: ASCII to Integer Conversion and vice versa
/// </summary>
namespace Session_5
{
    class Assi5
    {
        static void Main()
        {
            char[,] num = new char[3, 3] { { 'a', 'b', 'c' }, { 'd', 'e', 'f' }, { 'g', 'h', 'i' } };
            Console.WriteLine("Character Array between(A-I)");

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("\t{0}", num[i, j]);
                }
                Console.WriteLine();

            }
            Console.WriteLine("Integer Array (ASCII code of characters) : ");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("\t{0}", Convert.ToInt32(num[i, j]));

                }
                Console.WriteLine();

            }
            Console.ReadLine();
        }
       }
}
