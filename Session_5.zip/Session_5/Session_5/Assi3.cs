﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/// <summary>
/// Search elements from Jagged array
/// </summary>
namespace Session_5
{
    class Assi3
    {
        static void Main()
        {
            int[][] nums = new int[2][];
            nums[0] = new int[] { 13,15,19 };
            nums[1] = new int[] { 98,22 };
            int num = Convert.ToInt32(Console.ReadLine());
            int count = 0;

            for (int i = 0; i < 2; i++)
            {
                foreach (int x in nums[i])
                {
                    if (x == num)
                    {
                        count++;
                        break;
                    }

                }
                if (count > 0)
                {
                    break;
                }

            }
            if (count > 0)
            {
                Console.WriteLine("{0} found", num);
            }
            else
            {
                Console.WriteLine("{0} not found", num);
            }
            Console.ReadLine();
        }
    }
}
