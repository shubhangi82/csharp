﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/// <summary>
/// QUE: Calculate factorial of number using function
/// </summary>
namespace Session_6
{
    class Assi1
    {
        public int factorial(int n)
        {
            int factorial = 1;
            for (int i = n; i > 0; i--)
            {
                factorial = factorial * i;
            }
            return factorial;
        }
        static void Main()
        {
            Assi1 a = new Assi1();
            Console.WriteLine("Enter a number");
            Console.WriteLine($"factorial is {a.factorial(Convert.ToInt32(Console.ReadLine()))} ");
            Console.ReadLine();
        }
    }
}
