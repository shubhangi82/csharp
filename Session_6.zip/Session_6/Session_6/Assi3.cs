﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/// <summary>
/// QUE: Program to calculate Simple Intrest using function
/// </summary>
namespace Session_6
{
    class Assi3
    {
        static double SimpleIntrest(double amt, int month)
        {
            double Totalamt = amt * 5 * month / 100;
            return Totalamt;
        }

        static void Main()
        {
            Console.WriteLine("enter amount");
            double amt = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("enter months");
            int month = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"{SimpleIntrest(amt, month)}");
            Console.ReadLine();
        }
    }
}
