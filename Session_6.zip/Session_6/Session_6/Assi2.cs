﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/// <summary>
/// QUE: Search elements from jagged array using function
/// </summary>
namespace Session_6
{
    class Assi2
    {
        public string SearchJaggedArr(int[][] a, int n)
        {

            for (int i = 0; i < a.Length; i++)
            {
                foreach (int temp in a[i])
                {
                    if (temp == n)
                    {
                        return "found";
                    }
                }
            }
            return "not found";
        }
        static void Main()
        {
            Console.WriteLine("enter a number to search");
            int x = Convert.ToInt32(Console.ReadLine());
            int[][] arr = new int[3][];
            arr[0] = new int[] { 10,20,30,40};
            arr[1] = new int[] { 66,44,88 };
            arr[2] = new int[] { 9, 10 };

            Assi2 a = new Assi2();
            Console.WriteLine($"{x}:{a.SearchJaggedArr(arr, x)}");
            Console.ReadLine();
        }
    }
}
