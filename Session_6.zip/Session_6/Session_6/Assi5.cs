﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/// <summary>
/// QUE: Program to calculate Gst amount using optional parameter
/// </summary>
namespace Session_6
{
    class Assi5
    {
        static double GST(double amt, double GST = 1)
        {
            return amt * GST / 100;
        }
        static void Main()
        {
            Console.WriteLine("enter your amount");
            double amt = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine($"gst Amount={GST(amt)}");
            Console.ReadLine();
        }
    }
}
