﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/// <summary>
/// QUE: Program to find Simple Intrest using Out parameter
/// </summary>
namespace Session_6
{
    class Assi4cs
    {
        public static double Intrest(int principle, int time, int rate, out double amt)   
        {

            double SI = (principle * time * rate) / 100;
            Console.WriteLine("Simple Intrest = Rs.{0} ", SI);

            amt = principle + SI;

            return amt;
        }

        static void Main()
        {
            Console.WriteLine("Enter Principal Amount : Rs.");
            int prin = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Time Duration : ");
            int time = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Rate of Intrest : ");
            int rate = Convert.ToInt32(Console.ReadLine());

            double amt;
            Console.WriteLine("Total Payable Amount = Rs.{0} ", Intrest(prin, time, rate, out amt));

            Console.ReadLine();
        }
    }
}
