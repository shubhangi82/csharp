﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/// <summary>
/// QUE: Write a program to print table of given number using for loop.
/// </summary>
namespace Session_4
{
    class Assi5
    {
        static void Main()
        {

            Console.WriteLine("Enter numbers: ");
            int num = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i <= 10; i++)
            {
                int table = num * i;
                Console.WriteLine("{0}*{1}={2}", num, i, table);
            }

            Console.ReadLine();
        }
    }
}
