﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/// <summary>
/// QUE: Write a program to display odd numbers between 1 to 50 using foreach from given array.
/// </summary>
namespace Session_4
{
    class Assi3
    {
        static void Main()
        {
            int[] arr = new int[50];
            Console.WriteLine("Enter numbers: ");
            for (int i = 0; i <= 5; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("odd no:");
            foreach (int x in arr)
            {
                if (x % 2 != 0 && x > 1 && x <= 50)
                {
                    Console.WriteLine(x);
                }
            }
            Console.ReadLine();
        }
    }
}
