﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/// <summary>
/// QUE:Odd numbers printing from 0 to 50 by using Do while loop.
/// </summary>
namespace Session_4
{
    class Assi2
    {
        static void Main()
        {
            int i = 0;
            Console.WriteLine("Odd numbers from 0 to 50");
            do
            {
                if (i % 2 != 0)
                {
                    Console.Write(" {0} ", i);
                }
                i++;
            } while (i <= 50);
            Console.ReadLine();
        }
    }
}
