﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/// <summary>
/// QUE: Write a program identify and display even number from given array using foreach Loop.
/// </summary>
namespace Session_4
{
    class Assi4
    {
        static void Main()
        {
            int[] arr = new int[50];
            Console.WriteLine("Enter numbers: ");
            for (int i = 0; i <= 5; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("even no:");
            foreach (int x in arr)
            {
                if (x % 2 == 0 && x > 1 && x <= 50)
                {
                    Console.WriteLine(x);
                }
            }
            Console.ReadLine();
        }
    }
}
