﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Session_8
{
    class Computer1
    {

        static void Main()
        {
            SuperComputer sc = new SuperComputer();
            sc.BootUp();
            sc.dispSuperComp();
            sc.ShutDown();
            Console.WriteLine();
            MainframeComputer mfc = new MainframeComputer();
            mfc.BootUp();
            mfc.dispMainframeComp();

            mfc.ShutDown();
            Console.WriteLine();

            MicroComputer mc = new MicroComputer();
            mc.BootUp();

            mc.dispMicroComp();
            mc.ShutDown();
            Console.WriteLine();


            Console.ReadLine();


        }
    }
}
