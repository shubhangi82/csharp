﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Session_8
{
    public sealed class Pen
    {
        public void StartWriting()
        {
            Console.WriteLine("Start Writing");
        }

        public void StopWriting()
        {
            Console.WriteLine("Stop Writing");
        }

        static void Main()
        {
            Pen p = new Pen();
            p.StartWriting();
            p.StopWriting();

            Console.ReadLine();
        }
    }
}
