﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Session_8
{
    class SuperComputer : Computer
    {
        public void dispSuperComp()
        {
            Console.WriteLine("Super Computer");
        }
    }
}
