﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Session_8
{
    class CurrentAccount : BankAccount
    {
        double balance = 50000;
        public void Deposit(double amount)
        {

            balance = balance + amount;
            Console.WriteLine($"Your Balance After Deposit is Rs.{balance} ");

        }

        public void Withdraw(double amount)
        {
            balance = balance - amount;
            Console.WriteLine($"Your Balance After Withdraw is Rs.{balance} ");

        }

    }
}
