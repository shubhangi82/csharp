﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Session_8
{
    abstract class Computer
    {
        public void BootUp()
        {
            Console.WriteLine("BootUp Function of Computer Class");
        }

        public void ShutDown()
        {
            Console.WriteLine("ShutDown function of Computer class");
        }
    }
}
