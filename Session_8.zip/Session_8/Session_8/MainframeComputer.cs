﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Session_8
{
    class MainframeComputer : Computer
    {
        public void dispMainframeComp()
        {
            Console.WriteLine("Mainframe Computer");
        }
    }
}
