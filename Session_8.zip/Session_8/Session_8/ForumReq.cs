﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/// <summary>
/// ForumReq
/// </summary>
namespace Session_8
{
    class ForumReq
    {
        //private attributes
        private long id;
        private string name;
        private string emailId;
        private string DateOfBirth;

        //properties
        public long Id { get; set; }
        public string Name { get; set; }
        public string EmailId { get; set; }
        public string DateOfBirth1 { get; set; }

        // default Constructor
            public ForumReq() 
        {

        }

        //parameterized constructor
        public ForumReq(long id, string name, string emailId, string dateOfBirth) 
        {
            this.id = id;
            this.name = name;
            this.emailId = emailId;
            this.DateOfBirth = DateOfBirth;


        }

        //Overrides ToString()
        public override string ToString()
        {
            return $"User ID : {id} \n User Name : {name} \n Email Id : {emailId} \n Date Of Birth : {DateOfBirth}";
        }

        public static bool CheckDuplicateEmail(List<ForumReq> users, string mail)
        {
            foreach (ForumReq temp in users)
            {
                if (temp.emailId == mail)
                {
                    return true;
                }
            }
            return false;
        }

        static void Main()
        {
            List<ForumReq> userList = new List<ForumReq>();
            int choice;
            do
            {
                Console.WriteLine("Enter User Id : ");
                long uid = Convert.ToInt64(Console.ReadLine());

                Console.WriteLine("Enter User Name : ");
                string unm = Console.ReadLine();

                Console.WriteLine("Enter Email Id : ");
                string email = Console.ReadLine();

                bool result = CheckDuplicateEmail(userList, email);
                while (result)
                {
                    Console.WriteLine("Sorry.Email Id Not Available");
                    email = Console.ReadLine();
                    result = CheckDuplicateEmail(userList, email);
                }

                Console.WriteLine("Enter Date of birth : ");
                string dob = Console.ReadLine();

                Console.WriteLine("User Details");
                Console.WriteLine();
                ForumReq user = new ForumReq(uid, unm, email, dob);

                Console.WriteLine(user.ToString());
                Console.WriteLine("Do You want to add more Users : ");
                Console.WriteLine("1.Add  2.Exit");
                choice = Convert.ToInt32(Console.ReadLine());

                userList.Add(user);
            } while (choice != 2);

            Console.ReadLine();

        }
    }
}
