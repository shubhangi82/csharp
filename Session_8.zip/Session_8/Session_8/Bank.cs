﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Session_8
{
    class Bank
    {
        static void Main()
        {
            Console.WriteLine("SAVING ACCOUNT");

            SavingAccount save = new SavingAccount();
            Console.WriteLine("Enter Amount To Deposit : ");
            double Depositamt = Convert.ToDouble(Console.ReadLine());
            save.Deposit(Depositamt);

            Console.WriteLine("Enter Amount To Withdraw : ");
            double withdrawamt = Convert.ToDouble(Console.ReadLine());

            save.Withdraw(withdrawamt);

            Console.WriteLine("CURRENT ACCOUNT");
            Console.WriteLine();

            CurrentAccount ca = new CurrentAccount();
            Console.WriteLine("Enter Amount To Deposit : ");
            double d = Convert.ToDouble(Console.ReadLine());

            ca.Deposit(d);

            Console.WriteLine("Enter Amount To Withdraw : ");
            double Withdraw = Convert.ToDouble(Console.ReadLine());

            ca.Withdraw(Withdraw);
            Console.ReadLine();
        }
    }
}
